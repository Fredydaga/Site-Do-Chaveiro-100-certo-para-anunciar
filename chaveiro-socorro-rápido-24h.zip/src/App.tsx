import React from 'react';
import { ChevronDown, PhoneCall } from 'lucide-react';

const whatsappNumber = '5549988901379';
const displayPhone = '(49) 98890-1379';
const generalMessage = 'Olá! Preciso de um chaveiro agora em Chapecó.';
const googleMapsLink = 'COLE AQUI O LINK DO SEU PERFIL';

function whatsappLink(message = generalMessage) {
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
}

function WhatsAppIcon({ className = 'whatsapp-icon' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2M12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.04 20.15C10.56 20.15 9.11 19.76 7.85 19L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 14.99 3.8 13.47 3.8 11.91C3.81 7.37 7.5 3.67 12.05 3.67M8.53 7.33C8.37 7.33 8.1 7.39 7.87 7.64C7.65 7.89 7.02 8.48 7.02 9.7C7.02 10.92 7.91 12.09 8.03 12.25C8.16 12.41 9.77 14.9 12.25 15.97C12.84 16.23 13.3 16.38 13.66 16.5C14.25 16.69 14.79 16.66 15.22 16.6C15.7 16.53 16.7 16 16.91 15.41C17.12 14.82 17.12 14.32 17.06 14.21C17 14.1 16.85 14.04 16.62 13.92C16.39 13.81 15.27 13.26 15.06 13.18C14.86 13.11 14.71 13.07 14.56 13.3C14.41 13.53 13.99 14.04 13.86 14.19C13.73 14.34 13.61 14.36 13.38 14.24C13.15 14.13 12.42 13.89 11.54 13.11C10.86 12.5 10.4 11.75 10.27 11.53C10.14 11.3 10.26 11.18 10.37 11.06C10.48 10.96 10.61 10.79 10.73 10.65C10.85 10.5 10.89 10.39 10.97 10.23C11.05 10.07 11.01 9.93 10.95 9.82C10.89 9.71 10.43 8.58 10.24 8.12C10.06 7.68 9.87 7.74 9.73 7.73C9.6 7.73 9.44 7.72 9.28 7.72C9.12 7.72 8.86 7.78 8.64 8.02L8.53 7.33Z" />
    </svg>
  );
}

function WhatsAppButton({
  children,
  message = generalMessage,
  className = '',
}: {
  children: React.ReactNode;
  message?: string;
  className?: string;
}) {
  return (
    <a
      className={`whatsapp-button ${className}`}
      href={whatsappLink(message)}
      target="_blank"
      rel="noreferrer"
    >
      <WhatsAppIcon />
      <span>{children}</span>
    </a>
  );
}

const trustItems = [
  'Atendimento 24 horas todos os dias',
  'Abertura sem estragar a porta',
  'Preço combinado antes de começar',
  'Atende Chapecó e região',
];

const chapecoNeighborhoods = [
  'Centro',
  'Passo dos Fortes',
  'Efapi',
  'São Cristóvão',
  'Líder',
  'Palmital',
  'Jardim América',
  'Santa Maria',
  'Bela Vista',
  'Presidente Médici',
  'Maria Goretti',
  'Seminário',
];

const regionCities = [
  'Xaxim',
  'Xanxerê',
  'Coronel Freitas',
  'Guatambu',
  'Cordilheira Alta',
];

const faqs = [
  [
    'Chaveiro 24h perto de mim em Chapecó: quanto tempo leva para chegar?',
    'Nosso atendimento é móvel e saímos de carro equipado assim que você entra em contato. Quando você chama no WhatsApp e informa o seu bairro em Chapecó, já passamos a previsão exata de deslocamento.',
  ],
  [
    'Quanto custa abrir carro em Chapecó?',
    'O valor varia de acordo com a marca, o modelo do carro e o sistema de travas. Passamos o orçamento fechado pelo WhatsApp antes de sair para o atendimento, e você só autoriza o serviço se concordar.',
  ],
  [
    'Quanto custa para abrir uma porta de casa trancada?',
    'O valor depende do tipo de fechadura (comum, tetra, multiponto ou digital). Passamos o valor exato antecipadamente pelo WhatsApp antes de iniciar o atendimento.',
  ],
  [
    'Como funciona a abertura de carro sem chave?',
    'A abertura é realizada com ferramentas profissionais próprias para a fechadura do veículo. Não quebramos vidros, não forçamos as trancas e não arranhamos a lata nem a pintura do carro.',
  ],
  [
    'Vocês atendem de madrugada e fins de semana em Chapecó?',
    'Sim! O nosso atendimento é 24 horas todos os dias da semana, incluindo madrugadas, sábados, domingos e feriados.',
  ],
  [
    'Vai estragar minha porta residencial ou meu carro?',
    'Não. Usamos técnicas profissionais e ferramentas especializadas para destravar o miolo sem danificar a fechadura, sem furar a porta e sem riscar o veículo.',
  ],
  [
    'Quais bairros de Chapecó vocês atendem?',
    'Atendemos todos os bairros de Chapecó: Centro, Passo dos Fortes, Efapi, São Cristóvão, Líder, Palmital, Jardim América, Santa Maria, Bela Vista, Presidente Médici, Maria Goretti, Seminário e áreas próximas.',
  ],
  [
    'Vocês atendem outras cidades da região além de Chapecó?',
    'Sim! Atendemos também as cidades da região, como Xaxim, Xanxerê, Coronel Freitas, Guatambu e Cordilheira Alta, com deslocamento ágil.',
  ],
  [
    'A chave quebrou dentro da fechadura, vocês conseguem tirar e abrir?',
    'Sim. Utilizamos ferramentas de extração para remover o pedaço quebrado com cuidado, preservando o cilindro e abrindo a porta na hora.',
  ],
  [
    'Vocês abrem fechadura tetra e multiponto de alta segurança?',
    'Sim. Realizamos abertura técnica de fechaduras simples, fechaduras tetra, cilindros multiponto e travas de segurança residenciais ou comerciais.',
  ],
  [
    'Vocês têm loja física ou o atendimento é no local?',
    'Não temos loja física porque nosso atendimento é 100% móvel. Vamos diretamente até onde você estiver (casa, apartamento, empresa ou na rua), o que torna a chegada muito mais rápida.',
  ],
  [
    'Quais são as formas de pagamento aceitas?',
    'Aceitamos PIX, cartões de crédito e débito e dinheiro direto no local após o serviço concluído.',
  ],
];

export default function App() {
  return (
    <main>
      {/* Header */}
      <header className="site-header">
        <div className="container header-inner">
          <a className="brand" href="#inicio" aria-label="Chaveiro Socorro Rápido 24h">
            <img
              src="https://res.cloudinary.com/gdei5avj/image/upload/f_auto/q_auto/Logo_Chaveiro_Socorro_Ra%CC%81pido_24h.png"
              alt="Logo Chaveiro Socorro Rápido 24h"
              className="brand-logo"
              width="220"
              height="48"
            />
          </a>
          <div className="header-contact">
            <a href={`tel:+${whatsappNumber}`} className="flex items-center gap-1.5 hover:text-[#f0c938] transition-colors">
              <PhoneCall className="w-4 h-4 text-[#f0c938]" />
              {displayPhone}
            </a>
            <WhatsAppButton className="header-whatsapp" message={generalMessage}>
              WhatsApp
            </WhatsAppButton>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero" id="inicio" aria-labelledby="hero-title">
        <div className="hero-image" aria-hidden="true">
          <img
            src="/images/locksmith-hero.webp"
            alt="Chaveiro 24h em Chapecó e região"
            className="hero-img-element"
            width="1400"
            height="700"
            loading="eager"
          />
        </div>
        <div className="container hero-inner">
          <div>
            <div className="availability-tag">
              Atendimento 24 horas em Chapecó e região
            </div>
          </div>

          <div className="hero-copy">
            <h1 id="hero-title">
              Trancado para fora de casa ou do carro? <em>Atendimento rápido</em>, em Chapecó e região.
            </h1>
            <p className="hero-subtitle">
              Abrimos sua casa, apartamento ou veículo sem estragar a fechadura e sem danificar a lataria. Atendimento no local dia e noite, inclusive fins de semana e feriados.
            </p>

            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <WhatsAppButton className="hero-cta" message={generalMessage}>
                Chamar chaveiro no WhatsApp
              </WhatsAppButton>
              <a href={`tel:+${whatsappNumber}`} className="phone-button">
                <PhoneCall />
                Ligar {displayPhone}
              </a>
            </div>

            <p className="microcopy">
              Passamos o valor antes de começar. Atendimento 100% no local.
            </p>

            {/* Imagem de Chapecó */}
            <div className="hero-chapeco-banner">
              <img
                src="https://res.cloudinary.com/gdei5avj/image/upload/f_auto/q_auto/chapeco-1600.webp"
                alt="Chaveiro 24 horas atendendo Chapecó e cidades vizinhas"
                className="chapeco-img"
                width="1200"
                height="450"
                loading="eager"
              />
            </div>
          </div>

          <p className="hero-note">Atendimento direto no local com carro de socorro equipado.</p>
        </div>
      </section>

      {/* Trust Strip */}
      <section className="trust-strip" aria-label="Diferenciais">
        <div className="container trust-grid">
          {trustItems.map((text) => (
            <div className="trust-item" key={text}>
              <span>{text}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Services Section */}
      <section className="section services" id="servicos" aria-labelledby="services-title">
        <div className="container">
          <h2 id="services-title">O que você precisa abrir agora?</h2>
          <p className="section-intro">
            Abertura emergencial residencial, para condomínios e automotiva com ferramentas especializadas.
          </p>

          <div className="service-grid">
            {/* Casa / Residencial */}
            <article className="service-card">
              <div className="service-image-box">
                <img
                  src="/images/locksmith-home.webp"
                  alt="Chaveiro abrindo porta de casa em Chapecó"
                  className="service-img"
                  width="600"
                  height="400"
                  loading="lazy"
                />
              </div>
              <div className="service-content">
                <h3>Trancado fora de casa</h3>
                <p>
                  Perdeu a chave, esqueceu a chave pelo lado de dentro ou a chave quebrou no miolo?
                  Abrimos portas residenciais de madeira, ferro ou alumínio, portões e fechaduras comuns ou de segurança.
                  O chaveiro chega ao local com ferramentas próprias para destravar a porta sem quebrar o miolo e sem arrombar o batente.
                </p>
                <WhatsAppButton message="Olá! Estou trancado fora de casa. Preciso de ajuda agora em Chapecó.">
                  Abrir minha casa
                </WhatsAppButton>
              </div>
            </article>

            {/* Carro / Automotivo */}
            <article className="service-card">
              <div className="service-image-box">
                <img
                  src="/images/locksmith-car.webp"
                  alt="Chaveiro abrindo carro em Chapecó sem danificar"
                  className="service-img"
                  width="600"
                  height="400"
                  loading="lazy"
                />
              </div>
              <div className="service-content">
                <h3>Trancado fora do carro</h3>
                <p>
                  Chave esquecida na ignição, trancada dentro do porta-malas ou alarme travou o veículo?
                  Atendemos carros nacionais, importados, caminhonetes e utilitários em qualquer rua, garagem ou estacionamento de Chapecó.
                  Abertura técnica especializada que não risca a lataria, não entorta a porta e não quebra nenhum vidro.
                </p>
                <WhatsAppButton message="Olá! Estou trancado fora do carro. Preciso de ajuda agora em Chapecó.">
                  Abrir meu carro
                </WhatsAppButton>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* Seção de Cobertura: Bairros de Chapecó e Cidades Vizinhas */}
      <section className="section coverage-section" id="cobertura" aria-labelledby="coverage-title">
        <div className="container">
          <h2 id="coverage-title">Bairros de Chapecó e cidades da região que atendemos</h2>
          <p className="section-intro">
            Atendimento 100% móvel no seu local. O chaveiro sai imediatamente em carro equipado para abrir sua residência, comércio ou veículo.
          </p>

          <div className="coverage-grid">
            <div className="coverage-card">
              <h3>Bairros atendidos em Chapecó</h3>
              <p>
                Atendimento rápido para emergências em todos os principais bairros de Chapecó — SC:
              </p>
              <ul className="coverage-list">
                {chapecoNeighborhoods.map((bairro) => (
                  <li key={bairro}>{bairro}</li>
                ))}
              </ul>
              <p className="coverage-note">
                Também atendemos condomínios fechados, loteamentos e áreas comerciais de Chapecó.
              </p>
            </div>

            <div className="coverage-card">
              <h3>Cidades vizinhas atendidas na região</h3>
              <p>
                Deslocamento ágil para socorro emergencial nos municípios da grande Chapecó:
              </p>
              <ul className="coverage-list">
                {regionCities.map((cidade) => (
                  <li key={cidade}>{cidade}</li>
                ))}
              </ul>
              <p className="coverage-note">
                Tempo estimado e valor da corrida combinados antecipadamente pelo WhatsApp.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="section how-section" id="como-funciona" aria-labelledby="how-title">
        <div className="container narrow">
          <h2 id="how-title">Como funciona o atendimento</h2>
          <ol className="simple-steps-list">
            <li className="simple-step-item">
              <span className="step-num">1.</span>
              <div>
                <h3>Chame no WhatsApp</h3>
                <p>Mande sua localização e o que você precisa abrir (casa, apartamento ou carro).</p>
              </div>
            </li>
            <li className="simple-step-item">
              <span className="step-num">2.</span>
              <div>
                <h3>Combinamos o valor e o tempo</h3>
                <p>Passamos o preço certinho antes de sair e informamos em quanto tempo chegamos até você.</p>
              </div>
            </li>
            <li className="simple-step-item">
              <span className="step-num">3.</span>
              <div>
                <h3>Abertura no local sem estragar</h3>
                <p>O chaveiro realiza a abertura no seu local com ferramentas técnicas e você volta para sua rotina.</p>
              </div>
            </li>
          </ol>

          <WhatsAppButton message={generalMessage}>
            Chamar agora pelo WhatsApp
          </WhatsAppButton>
        </div>
      </section>

      {/* Why Section */}
      <section className="section why-section" id="sobre" aria-labelledby="why-title">
        <div className="container">
          <div className="why-layout">
            <div>
              <h2 id="why-title">Atendimento direto de Chapecó</h2>
              <p className="section-intro">
                Socorro rápido e direto para você entrar na sua casa ou no seu carro sem dor de cabeça.
              </p>
            </div>
            <div className="clean-why-grid">
              <div className="clean-why-item">
                <strong>Chaveiro da região</strong>
                <p>Atendimento rápido em Chapecó e cidades próximas.</p>
              </div>
              <div className="clean-why-item">
                <strong>Abertura sem danos</strong>
                <p>Ferramentas certas para abrir sem quebrar nada.</p>
              </div>
              <div className="clean-why-item">
                <strong>Preço combinado antes</strong>
                <p>Você sabe exatamente quanto vai pagar antes de começar.</p>
              </div>
              <div className="clean-why-item">
                <strong>Plantão 24 horas</strong>
                <p>Atendemos de madrugada, fins de semana e feriados.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Avaliações de Clientes (Pronta para preencher) */}
      <section className="section reviews-section" id="avaliacoes" aria-labelledby="reviews-title">
        <div className="container">
          <h2 id="reviews-title">Avaliações de Clientes</h2>
          <p className="section-intro">
            Depoimentos reais de quem precisou de abertura emergencial com o Chaveiro Socorro Rápido 24h em Chapecó.
          </p>

          <div className="reviews-grid">
            <div className="review-card">
              <div className="review-stars" aria-label="Avaliação 5 estrelas">★★★★★</div>
              <p className="review-text">
                "Esqueci a chave dentro do carro no estacionamento do Shopping Pátio Chapeco e o socorro foi incrivelmente rápido, destrancando a porta em poucos minutos sem deixar absolutamente nenhum arranhão no meu veículo"
              </p>
              <div className="review-author">
                <strong>Mateus Rogoski</strong>
                <span>Cliente • Chapecó - SC</span>
              </div>
            </div>

            <div className="review-card">
              <div className="review-stars" aria-label="Avaliação 5 estrelas">★★★★★</div>
              <p className="review-text">
                "Perdi minhas chaves voltando do trabalho e acabei trancado do lado de fora de madrugada, mas o profissional chegou em menos de 10 minutos e abriu minha porta com total agilidade e respeito."
              </p>
              <div className="review-author">
                <strong>Eduarda Zagonel</strong>
                <span>Cliente • Chapecó - SC</span>
              </div>
            </div>

            <div className="review-card">
              <div className="review-stars" aria-label="Avaliação 5 estrelas">★★★★★</div>
              <p className="review-text">
                "A fechadura da minha casa travou do nada e eu estava desesperado para entrar, mas o chaveiro resolveu a abertura de emergência rapidamente, foi super educado e cobrou um valor muito justo pelo excelente serviço"
              </p>
              <div className="review-author">
                <strong>Gabriel Ramos</strong>
                <span>Cliente • Chapecó - SC</span>
              </div>
            </div>
          </div>

          <div className="reviews-footer-note">
            <p>
              Já utilizou nossos serviços? Veja ou deixe sua avaliação no nosso perfil do Google:{' '}
              <a href={googleMapsLink} target="_blank" rel="noreferrer" className="underline font-bold text-[#111315]">
                Ver perfil no Google Maps
              </a>
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section faq-section" id="faq" aria-labelledby="faq-title">
        <div className="container narrow">
          <h2 id="faq-title">Dúvidas frequentes</h2>
          <div className="faq-list">
            {faqs.map(([question, answer]) => (
              <details key={question}>
                <summary>
                  <span>{question}</span>
                  <ChevronDown aria-hidden="true" />
                </summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="final-cta">
        <div className="container">
          <h2>Não fique esperando na rua</h2>
          <p>Chame agora no WhatsApp e resolvemos com atendimento rápido.</p>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <WhatsAppButton message={generalMessage}>
              Chamar no WhatsApp agora
            </WhatsAppButton>
            <a href={`tel:+${whatsappNumber}`} className="phone-button-dark">
              <PhoneCall />
              Ligar para {displayPhone}
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <div className="container footer-inner">
          <div className="footer-info">
            <img
              src="https://res.cloudinary.com/gdei5avj/image/upload/f_auto/q_auto/Logo_Chaveiro_Socorro_Ra%CC%81pido_24h.png"
              alt="Logo Chaveiro Socorro Rápido 24h"
              className="footer-logo"
              width="150"
              height="46"
            />
            <div>
              <strong>Chaveiro Socorro Rápido 24h</strong>
              <p className="text-xs text-[#999999] m-0">
                Atendimento 24 horas em Chapecó e região — SC • Atendimento móvel no local, sem loja física
              </p>
            </div>
          </div>
          <div className="footer-links">
            <a href={`tel:+${whatsappNumber}`}>
              <PhoneCall className="w-4 h-4 text-[#f0c938]" />
              {displayPhone}
            </a>
            <a href={whatsappLink(generalMessage)} target="_blank" rel="noreferrer" className="whatsapp-link-text">
              <WhatsAppIcon />
              Chamar no WhatsApp
            </a>
            <a href={googleMapsLink} target="_blank" rel="noreferrer" className="text-xs text-[#999999] hover:text-[#f0c938]">
              Google Maps
            </a>
          </div>
        </div>
      </footer>

      {/* Mobile Sticky Bar */}
      <a
        className="mobile-sticky"
        href={whatsappLink(generalMessage)}
        target="_blank"
        rel="noreferrer"
        aria-label="Chamar no WhatsApp agora"
      >
        <WhatsAppIcon />
        <span>Chamar no WhatsApp agora</span>
      </a>
    </main>
  );
}
